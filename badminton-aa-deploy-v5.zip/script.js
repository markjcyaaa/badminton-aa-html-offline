
class PreciseCalculator {
    static add = (a, b) => (+a) + (+b);
    static subtract = (a, b) => (+a) - (+b);
    static multiply = (a, b) => (+a) * (+b);
    static divide = (a, b) => (+a) / (+b);
    static round = (num, places = 2) => Math.round(num * (10 ** places)) / (10 ** places);

    static calculate(members) {
        if (members.length === 0) return null;
        let totalExpense = members.reduce((sum, m) => this.add(sum, m.expense), 0);
        let avgExpense = this.divide(totalExpense, members.length);
        let results = members.map(m => ({ ...m, difference: this.subtract(m.expense, avgExpense) }));
        return { totalExpense, avgExpense, memberCount: members.length, results };
    }
}

function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    document.getElementById(`btn-${tabId}`).classList.add('active');
    if(tabId === 'ball-calc') updateMemberSelects();
}

function showToast(message, isError = false) {
    const toast = document.createElement('div');
    toast.className = `toast ${isError ? 'error' : ''}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => toast.remove(), 3000);
}

function validateInput(e) { if (parseFloat(e.target.value) < 0) e.target.value = '0'; }

function addMember(){
    const nameLetters=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
    const list = document.getElementById('memberList');
    if(list.querySelector('.empty-state')) list.querySelector('.empty-state').remove();
    const index = list.querySelectorAll('.member-item').length;
    const name = index < nameLetters.length ? nameLetters[index] : '成员'+(index+1);
    const item = document.createElement('div');
    item.className = 'member-item';
    item.innerHTML = `<input type='text' class='name-input' value='${name}' placeholder='姓名' onchange='updateMemberSelects()'><input type='number' class='number-input' placeholder='场地费用' min='0' step='1'><input type='number' class='number-input' placeholder='球费' min='0' step='1'><button class='btn btn-danger' onclick='removeMember(this)'>&times;</button>`;
    list.appendChild(item);
    item.querySelectorAll('input').forEach(i => i.addEventListener('input', validateInput));
    setupPlaceholders();
}

function removeMember(btn) {
    btn.closest('.member-item').remove();
    if(document.getElementById('memberList').children.length === 0){
        document.getElementById('memberList').innerHTML = `<div class='empty-state'><h3>还没有成员</h3><p>点击上方按钮添加成员</p></div>`;
    }
    updateMemberSelects();
}

function calculateAA() {
    const memberItems = document.querySelectorAll('.member-item');
    const members = Array.from(memberItems).map(item => {
        const inputs = item.querySelectorAll('input');
        return {
            name: inputs[0].value.trim(),
            price: parseFloat(inputs[1].value) || 0,
            shuttle: parseFloat(inputs[2].value) || 0,
            expense: PreciseCalculator.add(parseFloat(inputs[1].value) || 0, parseFloat(inputs[2].value) || 0)
        };
    }).filter(m => m.name);
    if (members.length === 0) { showToast('请先添加成员', true); return; }
    document.querySelector('.loading').classList.add('show');
    setTimeout(() => {
        const res = PreciseCalculator.calculate(members);
        updateResult(res);
        saveHistory(res); 
        document.querySelector('.loading').classList.remove('show');
    }, 300);
}

function updateResult(res) {
    const card = document.getElementById('resultCard');
    const summary = card.querySelector('.result-summary');
    const list = card.querySelector('.result-list');
    summary.innerHTML = `<div class='summary-item'><div class='value'>${res.memberCount}</div><div class='label'>参与人数</div></div><div class='summary-item'><div class='value'>¥${PreciseCalculator.round(res.totalExpense)}</div><div class='label'>总费用</div></div><div class='summary-item'><div class='value'>¥${PreciseCalculator.round(res.avgExpense)}</div><div class='label'>人均费用</div></div>`;
    list.innerHTML = res.results.map(r => {
        const diff = r.difference;
        const abs = PreciseCalculator.round(Math.abs(diff));
        let cls = diff > 0.01 ? 'positive' : (diff < -0.01 ? 'negative' : 'zero');
        let txt = diff > 0.01 ? `应收 ¥${abs}` : (diff < -0.01 ? `应付 ¥${abs}` : '无需收付');
        return `<div class='result-item'><div><div class='name'>${r.name}</div><div style='font-size:0.9rem;color:#6c757d;'>场地¥${r.price} + 球费¥${r.shuttle} = 总支出¥${r.expense}</div></div><div class='amount ${cls}'>${txt}</div></div>`;
    }).join('');
    card.style.display = 'block';
    card.scrollIntoView({ behavior: 'smooth' });
}

function addBallGroup() {
    const container = document.getElementById('ballGroupList');
    const div = document.createElement('div');
    div.className = 'ball-group-item';
    div.innerHTML = `<input type='number' class='number-input' placeholder='整桶球费用' min='0' step='1'><input type='number' class='number-input' placeholder='消耗球数' min='0' step='1'><button class='btn btn-danger' onclick='this.parentElement.remove()'>&times;</button>`;
    container.appendChild(div);
    setupPlaceholders();
}

function updateMemberSelects() {
    const select = document.getElementById('targetMemberSelect');
    const currentVal = select.value;
    const members = Array.from(document.querySelectorAll('.member-item .name-input')).map(i => i.value.trim()).filter(n => n);
    select.innerHTML = `<option value="">人 (不选择则仅计算)</option>`;
    members.forEach(name => {
        const opt = document.createElement('option');
        opt.value = name;
        opt.textContent = name;
        select.appendChild(opt);
    });
    select.value = currentVal;
}

function calculateBallFee() {
    const groups = document.querySelectorAll('.ball-group-item');
    let totalFee = 0;
    let detailStr = [];
    groups.forEach((g, idx) => {
        const inputs = g.querySelectorAll('input');
        const pricePerTube = parseFloat(inputs[0].value) || 0;
        const usedCount = parseFloat(inputs[1].value) || 0;
        if (pricePerTube > 0 && usedCount > 0) {
            const pricePerBall = pricePerTube / 12;
            const groupFee = pricePerBall * usedCount;
            totalFee += groupFee;
            detailStr.push(`第${idx+1}组: ${usedCount}颗 × ¥${PreciseCalculator.round(pricePerBall)}/颗 = ¥${PreciseCalculator.round(groupFee)}`);
        }
    });
    const finalFee = PreciseCalculator.round(totalFee);
    const resultDiv = document.getElementById('ballResult');
    resultDiv.style.display = 'block';
    resultDiv.innerHTML = `<div style="font-weight:bold;margin-bottom:10px;">总球费: <span style="color:#667eea;font-size:1.2rem;">¥${finalFee}</span></div><div style="font-size:0.9rem;color:#666;">${detailStr.join('<br>')}</div>`;
    const targetName = document.getElementById('targetMemberSelect').value;
    if (targetName) {
        const aaMembers = document.querySelectorAll('.member-item');
        aaMembers.forEach(item => {
            const nameInput = item.querySelector('.name-input');
            if (nameInput.value.trim() === targetName) {
                const allInputs = item.querySelectorAll('input');
                allInputs[2].value = finalFee;
                showToast(`已更新 ${targetName} 的球费: ¥${finalFee}`);
            }
        });
    }
}

const HISTORY_KEY = 'badminton_aa_v4_0';
function setupPlaceholders() {
    document.querySelectorAll('input[type="number"]').forEach(input => {
        if (!input.dataset.ph) input.dataset.ph = input.placeholder;
        input.addEventListener('focus', function() { this.placeholder = ''; });
        input.addEventListener('blur', function() { if (!this.value) this.placeholder = this.dataset.ph; });
    });
}
function saveHistory(res) {
    if (!res || !res.results || res.results.length === 0) return;
    try {
        const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
        const now = new Date();
        const timeStr = `${now.getMonth()+1}/${now.getDate()} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
        const names = res.results.map(r => r.name);
        let nameStr = names.slice(0, 3).join(', ');
        if (names.length > 3) nameStr += '...';
        history.unshift({ id: now.getTime(), title: `${nameStr} - ${timeStr}`, data: res });
        if (history.length > 50) history.pop();
        localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
        renderHistory();
        showToast('历史记录已保存');
    } catch (e) { console.error(e); }
}
function renderHistory() {
    const card = document.getElementById('historyCard');
    const list = document.getElementById('historyList');
    try {
        const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
        if (history.length === 0) { card.style.display = 'none'; return; }
        card.style.display = 'block';
        list.innerHTML = history.map(item => {
            const details = item.data.results.map(r => {
                const diff = r.difference;
                let txt = diff > 0.01 ? `<span style='color:#28a745'>收 ${PreciseCalculator.round(Math.abs(diff))}</span>` : (diff < -0.01 ? `<span style='color:#dc3545'>付 ${PreciseCalculator.round(Math.abs(diff))}</span>` : `<span>-</span>`);
                return `<div class='result-item' style='margin-bottom:5px;'><div class='name'>${r.name}</div><div class='amount'>${txt}</div></div>`;
            }).join('');
            return `<div class='history-item'><div class='history-title-bar' onclick='this.parentElement.classList.toggle("open")'><span>${item.title}</span><span>▼</span></div><div class='history-content'>${details}</div></div>`;
        }).join('');
    } catch (e) { card.style.display = 'none'; }
}
function clearHistory() { if(confirm('清空记录?')){ localStorage.removeItem(HISTORY_KEY); renderHistory(); } }

// --- V5.0 特性：首次访问弹窗 ---
function checkFirstVisit() {
    const hasVisited = localStorage.getItem('has_visited_intro_v5');
    if (!hasVisited) {
        const modal = document.createElement('div');
        modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:9999;display:flex;justify-content:center;align-items:center;padding:20px;backdrop-filter:blur(3px);animation:fadeIn 0.3s ease;';
        modal.innerHTML = `
            <div style="background:white;padding:30px;border-radius:20px;max-width:400px;text-align:center;box-shadow:0 15px 40px rgba(0,0,0,0.3);transform:scale(0.95);animation:scaleUp 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;">
                <div style="font-size:3.5rem;margin-bottom:15px;">👋</div>
                <h3 style="margin-bottom:10px;font-size:1.5rem;color:#333;">Hi there!</h3>
                <p style="color:#666;line-height:1.6;margin-bottom:20px;">这是一个帮助你快速计算球费的离线网页。<br>通常情况下，用你的直觉填写就能搞定了。</p>
                <div style="font-size:0.9rem;color:#888;margin-bottom:25px;background:#f8f9fa;padding:15px;border-radius:12px;text-align:left;">
                    <div style="margin-bottom:8px;">📧 如有疑问，请联系: <a href="mailto:jcyheixuan@gmail.com" style="color:#667eea;font-weight:bold;">jcyheixuan@gmail.com</a></div>
                    <div>⭐ 如果感觉好用，请给我的项目一个star: <a href="https://github.com/markjcyaaa/badminton-aa-html-offline/" target="_blank" style="color:#667eea;font-weight:bold;">GitHub Repo</a></div>
                </div>
                <button onclick="this.closest('div').parentElement.remove();localStorage.setItem('has_visited_intro_v5','true');" style="background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);color:white;border:none;padding:12px 40px;border-radius:30px;font-weight:bold;cursor:pointer;font-size:1rem;box-shadow:0 5px 15px rgba(102, 126, 234, 0.4);transition:transform 0.2s;">开始使用</button>
            </div>
            <style>@keyframes scaleUp{to{transform:scale(1);}}</style>
        `;
        document.body.appendChild(modal);
    }
}

window.addEventListener('DOMContentLoaded', () => {
    checkFirstVisit(); // 检查首次访问
    setupPlaceholders();
    renderHistory();
    let touchStartX = 0;
    document.body.addEventListener('touchstart', e => touchStartX = e.changedTouches[0].screenX);
    document.body.addEventListener('touchend', e => {
        if (e.changedTouches[0].screenX < touchStartX - 50) switchTab('ball-calc');
        if (e.changedTouches[0].screenX > touchStartX + 50) switchTab('aa-calc');
    });
});
